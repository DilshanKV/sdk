// Copyright 2021 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/version_strings.h"
#include "pex/sdk/internal/export_macros.h"

#include <stdbool.h>

#if !defined(PEX_SDK_MAJOR_VERSION) || !defined(PEX_SDK_MINOR_VERSION)
#error You must #define PEX_SDK_MAJOR_VERSION and PEX_SDK_MINOR_VERSION prior to including version.h
#elif PEX_SDK_MAJOR_VERSION != PEX_SDK_MAJOR_VERSION_INTERNAL
#error bindings version not supported
#elif PEX_SDK_MINOR_VERSION > PEX_SDK_MINOR_VERSION_INTERNAL
#error bindings version not supported
#endif

#ifdef __cplusplus
extern "C" {
#endif

PEX_SDK_EXPORT bool Pex_Version_IsCompatible(int major, int minor);

#ifdef __cplusplus
}  // extern "C"
#endif
