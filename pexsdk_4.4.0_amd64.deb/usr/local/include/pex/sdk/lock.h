// Copyright 2021 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/internal/export_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

PEX_SDK_EXPORT void Pex_Lock();
PEX_SDK_EXPORT void Pex_Unlock();

#ifdef __cplusplus
}  // extern "C"
#endif
