// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include <stdbool.h>

#include "pex/sdk/internal/export_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Pex_Status Pex_Status;

PEX_SDK_EXPORT Pex_Status* Pex_Status_New();
PEX_SDK_EXPORT void Pex_Status_Delete(Pex_Status**);
PEX_SDK_EXPORT bool Pex_Status_OK(const Pex_Status* status);
PEX_SDK_EXPORT int Pex_Status_GetCode(const Pex_Status* status);
PEX_SDK_EXPORT const char* Pex_Status_GetMessage(const Pex_Status* status);

#ifdef __cplusplus
}  // extern "C"
#endif
