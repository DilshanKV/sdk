// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#define PEX_SDK_VERSION_INTERNAL "4.4.0"
#define PEX_SDK_MAJOR_VERSION_INTERNAL 4
#define PEX_SDK_MINOR_VERSION_INTERNAL 4
