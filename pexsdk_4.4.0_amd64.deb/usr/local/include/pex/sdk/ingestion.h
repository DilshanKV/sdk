// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/client.h"
#include "pex/sdk/fingerprint.h"
#include "pex/sdk/status.h"
#include "pex/sdk/internal/export_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Pex_ListRequest Pex_ListRequest;

PEX_SDK_EXPORT Pex_ListRequest* Pex_ListRequest_New();
PEX_SDK_EXPORT void Pex_ListRequest_Delete(Pex_ListRequest**);

PEX_SDK_EXPORT void Pex_ListRequest_SetAfter(Pex_ListRequest* rq, const char* after);
PEX_SDK_EXPORT void Pex_ListRequest_SetLimit(Pex_ListRequest* rq, int limit);

//-----------------------------------------------------------------------------

typedef struct Pex_ListResult Pex_ListResult;

PEX_SDK_EXPORT Pex_ListResult* Pex_ListResult_New();
PEX_SDK_EXPORT void Pex_ListResult_Delete(Pex_ListResult**);

PEX_SDK_EXPORT const char* Pex_ListResult_GetJSON(Pex_ListResult* rs);

//-----------------------------------------------------------------------------
//
PEX_SDK_EXPORT void Pex_Ingest(Pex_Client* c, const char* provided_id, const Pex_Buffer* ft,
                               Pex_Status* status);

PEX_SDK_EXPORT void Pex_Archive(Pex_Client* c, const char* provided_id, int ft_types,
                                Pex_Status* status);

PEX_SDK_EXPORT void Pex_List(Pex_Client* c, const Pex_ListRequest* req, Pex_ListResult* res,
                             Pex_Status* status);

#ifdef __cplusplus
}  // extern "C"
#endif
