// Copyright 2022 Pexeso Inc. All rights reserved.

#pragma once

// The case of static library build is intentionally not handled, because
// pex-sdk isn't supposed to ever be built as a static library.
#if defined(_WIN32)
#  if defined(PEX_SDK_BUILD_LIBRARY)
#    define PEX_SDK_EXPORT __declspec(dllexport)
#  else
#    define PEX_SDK_EXPORT __declspec(dllimport)
#  endif
#else
#define PEX_SDK_EXPORT __attribute__((visibility("default")))
#endif
