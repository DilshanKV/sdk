// Copyright 2023 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/fingerprint.h"
#include "pex/sdk/status.h"
#include "pex/sdk/client.h"
#include "pex/sdk/internal/export_macros.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum Pex_SearchType {
  Pex_SearchType_Default = 0,
  Pex_SearchType_IdentifyMusic = 1,
  Pex_SearchType_FindMatches = 2,
} Pex_SearchType;

//-----------------------------------------------------------------------------
// Pex_StartSearchRequest
typedef struct Pex_StartSearchRequest Pex_StartSearchRequest;

PEX_SDK_EXPORT Pex_StartSearchRequest* Pex_StartSearchRequest_New();
PEX_SDK_EXPORT void Pex_StartSearchRequest_Delete(Pex_StartSearchRequest**);

PEX_SDK_EXPORT void Pex_StartSearchRequest_SetFingerprint(Pex_StartSearchRequest* rq,
                                                          const Pex_Buffer* ft, Pex_Status* s);
PEX_SDK_EXPORT void Pex_StartSearchRequest_SetType(Pex_StartSearchRequest* rq, Pex_SearchType type);

//-----------------------------------------------------------------------------
// Pex_StartSearchResult
typedef struct Pex_StartSearchResult Pex_StartSearchResult;

PEX_SDK_EXPORT Pex_StartSearchResult* Pex_StartSearchResult_New();
PEX_SDK_EXPORT void Pex_StartSearchResult_Delete(Pex_StartSearchResult**);

/**
 * Retrieves lookup ID at provided index. These are used to complete the search later.
 *
 * Returns true when the index was valid, and `lookup_id` points to a string
 * representation of the string. `idx` is incremented after each call.
 */
PEX_SDK_EXPORT bool Pex_StartSearchResult_NextLookupID(const Pex_StartSearchResult* rs, size_t* idx,
                                                       char const** lookup_id);

//-----------------------------------------------------------------------------
// Pex_CheckSearchRequest
typedef struct Pex_CheckSearchRequest Pex_CheckSearchRequest;

PEX_SDK_EXPORT Pex_CheckSearchRequest* Pex_CheckSearchRequest_New();
PEX_SDK_EXPORT void Pex_CheckSearchRequest_Delete(Pex_CheckSearchRequest**);

//! Adds a lookup ID from the search start to be completed
PEX_SDK_EXPORT void Pex_CheckSearchRequest_AddLookupID(Pex_CheckSearchRequest* rq,
                                                       const char* lookup_id);

//-----------------------------------------------------------------------------
// Pex_CheckSearchResult
typedef struct Pex_CheckSearchResult Pex_CheckSearchResult;

PEX_SDK_EXPORT Pex_CheckSearchResult* Pex_CheckSearchResult_New();
PEX_SDK_EXPORT void Pex_CheckSearchResult_Delete(Pex_CheckSearchResult**);

PEX_SDK_EXPORT const char* Pex_CheckSearchResult_GetJSON(const Pex_CheckSearchResult* rs);

//-----------------------------------------------------------------------------
// Search
PEX_SDK_EXPORT void Pex_StartSearch(Pex_Client* c, const Pex_StartSearchRequest* rq,
                                    Pex_StartSearchResult* rs, Pex_Status* s);
PEX_SDK_EXPORT void Pex_CheckSearch(Pex_Client* c, const Pex_CheckSearchRequest* rq,
                                    Pex_CheckSearchResult* rs, Pex_Status* s);

#ifdef __cplusplus
}  // extern "C"
#endif
