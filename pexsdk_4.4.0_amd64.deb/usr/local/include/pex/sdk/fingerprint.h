// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/status.h"
#include "pex/sdk/buffer.h"
#include "pex/sdk/client.h"
#include "pex/sdk/internal/export_macros.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum Pex_Fingerprint_Type {
  Pex_Fingerprint_Type_Video = 1,
  Pex_Fingerprint_Type_Audio = 2,
  Pex_Fingerprint_Type_Melody = 4,
  Pex_Fingerprint_Type_All =
      Pex_Fingerprint_Type_Video | Pex_Fingerprint_Type_Audio | Pex_Fingerprint_Type_Melody
} Pex_Fingerprint_Type;

PEX_SDK_EXPORT void Pex_Fingerprint_File(const char* file, Pex_Buffer* ft, Pex_Status* status,
                                         int ft_types);
PEX_SDK_EXPORT void Pex_Fingerprint_Buffer(const Pex_Buffer* buf, Pex_Buffer* ft,
                                           Pex_Status* status, int ft_types);

PEX_SDK_EXPORT void Pex_FingerprintFile(Pex_Client* client, const char* file, Pex_Buffer* ft,
                                        Pex_Status* status, int ft_types);
PEX_SDK_EXPORT void Pex_FingerprintBuffer(Pex_Client* client, const Pex_Buffer* buf, Pex_Buffer* ft,
                                          Pex_Status* status, int ft_types);

#ifdef __cplusplus
}  // extern "C"
#endif
