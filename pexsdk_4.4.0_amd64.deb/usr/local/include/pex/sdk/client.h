// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/status.h"
#include "pex/sdk/internal/export_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

//-----------------------------------------------------------------------------
// Pex_ClientType
typedef enum Pex_ClientType {
  Pex_PRIVATE_SEARCH = 0,
  Pex_PEX_SEARCH = 1,
} Pex_ClientType;

//-----------------------------------------------------------------------------
// Pex_Client
typedef struct Pex_Client Pex_Client;

PEX_SDK_EXPORT Pex_Client* Pex_Client_New();
PEX_SDK_EXPORT void Pex_Client_Delete(Pex_Client**);

PEX_SDK_EXPORT void Pex_Client_Init(Pex_Client* c, Pex_ClientType type, const char* client_id,
                                   const char* client_secret, Pex_Status* s);

#ifdef __cplusplus
}  // extern "C"
#endif
