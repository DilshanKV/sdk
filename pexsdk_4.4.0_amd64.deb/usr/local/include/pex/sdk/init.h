// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/internal/export_macros.h"

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

PEX_SDK_EXPORT void Pex_Init(const char* client_id, const char* client_secret, int* status_code,
                            char* status_message, size_t status_message_size);
PEX_SDK_EXPORT void Pex_Cleanup();

#ifdef __cplusplus
}  // extern "C"
#endif
