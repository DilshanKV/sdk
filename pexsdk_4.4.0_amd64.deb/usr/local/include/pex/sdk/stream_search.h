// Copyright 2022 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/buffer.h"
#include "pex/sdk/client.h"
#include "pex/sdk/status.h"
#include "pex/sdk/internal/export_macros.h"

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
  kStreamEventSearchStarted,  ///< Sent when the search has started (before matches were found)
  kStreamEventMatchStarted,   ///< Sent when a match in the is first found.
  kStreamEventMatchEnded,     ///< Sent when a previously started match in the stream has ended.
  kStreamEventStreamEnded,    ///< Sent when input stream has ended.
  kStreamEventSearchEnded,    ///< Sent when the search has ended and no more events will be sent.
  kStreamEventSearchError,    ///< Sent when the search has failed with an error (e.g. downloading a
                              ///< stream chunk has failed)
} Pex_StreamMatchEventType;

typedef struct Pex_StreamSearchEvent Pex_StreamSearchEvent;
typedef struct Pex_StreamSearch Pex_StreamSearch;

PEX_SDK_EXPORT Pex_StreamSearch* Pex_StreamSearch_New();
PEX_SDK_EXPORT void Pex_StreamSearch_Delete(Pex_StreamSearch** ctx_ptr);
PEX_SDK_EXPORT void Pex_StreamSearch_SetStreamPath(Pex_StreamSearch* search_ctx, const char* str);
PEX_SDK_EXPORT void Pex_StreamSearch_SetClient(Pex_StreamSearch* search_ctx, Pex_Client* client);
//! Sets which fingerprints stream search should look for
PEX_SDK_EXPORT void Pex_StreamSearch_SetFingerprintTypes(Pex_StreamSearch* search_ctx,
                                                         int fingerprint_type);

//! Starts the actual stream search. StreamPath and Client need to be set first.
PEX_SDK_EXPORT void Pex_StreamSearch_StartSearch(Pex_StreamSearch* search_ctx, Pex_Status* status);

//! Blocks until the search has properly shutdown.
PEX_SDK_EXPORT void Pex_StreamSearch_EndSearch(Pex_StreamSearch* search_ctx);

/**
 * Retrieves current event from stream search. Blocks until there is an event.
 *
 * Returns non-ok status if no events could be retrieved, e.g. asking
 * for more events after the search has been stopped and thus no amount
 * of waiting can provide another event.
 */
PEX_SDK_EXPORT void Pex_StreamSearch_GetNextEvent(Pex_StreamSearch* search_ctx,
                                                  Pex_StreamSearchEvent* event_ctx,
                                                  Pex_Status* status);

PEX_SDK_EXPORT Pex_StreamSearchEvent* Pex_StreamSearchEvent_New();
PEX_SDK_EXPORT void Pex_StreamSearchEvent_Delete(Pex_StreamSearchEvent** ctx_ptr);

//! Returns the type of the provided event
PEX_SDK_EXPORT Pex_StreamMatchEventType
Pex_StreamSearchEvent_GetType(Pex_StreamSearchEvent const* event_ctx);

/**
 * Retrieves the Pex_Status from an error event.
 *
 * Can only be called on events with `kStreamEventSearchError` event type.
 *
 * On success `status` is OK and the retrieved status will be in `error`.
 * On failure, `status` is not OK, and `error` will be left in unspecified state.
 */
PEX_SDK_EXPORT void Pex_StreamSearchEvent_GetError(Pex_StreamSearchEvent const* event_ctx,
                                                   Pex_Status* error, Pex_Status* status);

/**
 * Returns segment type (audio, video, melody).
 *
 * If called on an event with a wrong type, `status` is not OK and the
 * return value is unspecified.
 */
PEX_SDK_EXPORT int Pex_StreamSearchEvent_GetSegmentType(Pex_StreamSearchEvent const* event_ctx,
                                                        Pex_Status* status);

/**
 * Returns the appropriate query timestamp from kStreamEventMatch{Started, Ended} event
 *
 * If called on an event with a wrong type, `status` is not OK and the
 * return value is unspecified.
 */
PEX_SDK_EXPORT int64_t
Pex_StreamSearchEvent_GetQueryTimestamp(Pex_StreamSearchEvent const* event_ctx, Pex_Status* status);
/**
 * Returns the appropriate query timestamp from kStreamEventMatch{Started, Ended} event
 *
 * If called on an event with a wrong type, `status` is not OK and the
 * return value is unspecified.
 */
PEX_SDK_EXPORT int64_t
Pex_StreamSearchEvent_GetAssetTimestamp(Pex_StreamSearchEvent const* event_ctx, Pex_Status* status);

/**
 * Retrieves the `Pex_Asset` from kStreamEventMatch{Started, Ended} event
 *
 * If called on an event with a wrong type, `status` is not OK and the
 * return value is unspecified.
 */
PEX_SDK_EXPORT void Pex_StreamSearchEvent_GetAsset(Pex_StreamSearchEvent const* event_ctx,
                                                   Pex_Buffer* json, Pex_Status* status);

#ifdef __cplusplus
}  // extern "C"
#endif
