// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include "pex/sdk/status.h"
#include "pex/sdk/client.h"
#include "pex/sdk/internal/export_macros.h"


#ifdef __cplusplus
extern "C" {
#endif

PEX_SDK_EXPORT void Pex_Mockserver_InitClient(Pex_Client* c, const char* exe_path, Pex_Status* s);

#ifdef __cplusplus
}  // extern "C"
#endif
