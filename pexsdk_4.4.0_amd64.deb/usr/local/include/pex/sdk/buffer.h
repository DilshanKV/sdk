// Copyright 2020 Pexeso Inc. All rights reserved.

#pragma once

#include <stddef.h>

#include "pex/sdk/internal/export_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Pex_Buffer Pex_Buffer;

PEX_SDK_EXPORT Pex_Buffer* Pex_Buffer_New();
PEX_SDK_EXPORT void Pex_Buffer_Delete(Pex_Buffer**);

PEX_SDK_EXPORT void Pex_Buffer_Set(Pex_Buffer* b, const void* buf, size_t size);
PEX_SDK_EXPORT const void* Pex_Buffer_GetData(const Pex_Buffer* b);
PEX_SDK_EXPORT size_t Pex_Buffer_GetSize(const Pex_Buffer* b);

#ifdef __cplusplus
}  // extern "C"
#endif
